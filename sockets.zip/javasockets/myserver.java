
import java.io.*;
import java.util.*;
import java.net.*;
import java.math.*;


public class myserver{
    public static void main(String[] args) throws IOException, InterruptedException
    {
        System.setProperty("java.net.preferIPv4Stack", "true");    

        System.out.println();
        System.out.println("waiting for the created chatrooms from the superclient:");
      

         byte[] buffer = new byte[1024];
         byte[] buffer1 = new byte[1024];
        
         ArrayList<String> chatrooms = new ArrayList<>();
         long timeInterval  = 0;
         DatagramSocket  mydatagramsocket = new DatagramSocket(4449);

        
        
            for(;;){


                try 
                {          // we try to receive the created groups from the superclient.

                        DatagramPacket chatroompacket = new DatagramPacket(buffer, buffer.length);
                        mydatagramsocket.receive(chatroompacket);
                        String newchatroom = new String(chatroompacket.getData(), 0, chatroompacket.getLength());

                        //adding the newly received chatroom to the array of chatrooms created
                           chatrooms.add(newchatroom); 
                        
                         if(chatrooms.size() == 3)    // we quit after receiving all the received groups.
                        {
                            break;
                        }  
                    }        
                    

                    catch (Exception e) {e.printStackTrace();  break;}         
                }


            for (String string : chatrooms) { // looping over the array of chatrooms created.
                    
                    System.out.print(string);  // printing the chatrooms created.
                    System.out.println();
                }

                    // receiving the time interval.
              //  DatagramSocket  mydatagramsocket = new DatagramSocket(4449);
                DatagramPacket timepacket = new DatagramPacket(buffer, buffer.length);
                mydatagramsocket.receive(timepacket);
                String interval = new String(timepacket.getData(), 0, timepacket.getLength());

                System.out.println();  
                
                int time = (Integer.parseInt(interval))*1000;  // we multiply 1000 to convert the milliseconds to seconds.

               System.out.println("the sending time interval: " + time);


                DatagramPacket datagramPacket = new DatagramPacket(buffer1, buffer1.length);
                mydatagramsocket.receive(datagramPacket);   
               
                byte[] buffer5 = new byte[1000];

                datagramPacket = new DatagramPacket(buffer5, buffer5.length);

                mydatagramsocket.receive(datagramPacket);

                InetAddress clientAdress = datagramPacket.getAddress();
                int clientPort = datagramPacket.getPort();

                int j = 0;

                   
                    //sends the choice menu to the clients.

                while(j < 3)
                {
                    byte[] chatroombuffer = new byte[1024];
                    chatroombuffer = chatrooms.get(j).getBytes();
                    datagramPacket = new DatagramPacket(chatroombuffer, chatroombuffer.length, clientAdress, clientPort);
                    mydatagramsocket.send(datagramPacket);

                    j++;

                }
         

                for(;;)
                {
                       // receiving the option/choice of group from the clients menu.

                        byte b[] = new byte[256];
                        DatagramPacket d = new DatagramPacket(b, b.length);
                        mydatagramsocket.receive(d); 
                    
                // messages to be sent to the client considering which IP address the choose. (group they choose)

                        InetAddress chatroom1 = InetAddress.getByName("225.1.2.3"); //addresses to send the messages to.
                        InetAddress chatroom2 = InetAddress.getByName("226.2.1.4"); //addresses to send the messages to.
                        InetAddress chatroom3 = InetAddress.getByName("227.3.2.1"); //addresses to send the messages to.
                    

                        String chat1 = "thanks for joining " + chatrooms.get(0);

                        String chat2 = "thanks for joining " + chatrooms.get(1);

                        String chat3 = "thanks for joining " + chatrooms.get(2);    

                        MulticastSocket socket = new MulticastSocket(); //creating a multicast socket
                        
                        DatagramPacket packet1 = new DatagramPacket(chat1.getBytes(), chat1.length(), chatroom1, 4000);
                        DatagramPacket packet2 = new DatagramPacket(chat2.getBytes(), chat2.length(), chatroom2, 4000);
                        DatagramPacket packet3 = new DatagramPacket(chat3.getBytes(), chat3.length(), chatroom3, 4000);
                       

                        while (true) 
                        {
                        socket.send(packet1);
                        socket.send(packet2);
                        socket.send(packet3);
                        
                        Thread.sleep(time);
                            
                        }
                      
                      
                }
            


        

          // mydatagramsocket.close();
        
        


    }
}