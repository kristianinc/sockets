import java.net.*;
import java.io.*;
import java.util.*;


public class myclients
{
    @SuppressWarnings("deprecation")
    public static void main(String[] args) throws IOException
    {
    
        System.setProperty("java.net.preferIPv4Stack", "true");

        DatagramSocket datagramSocket = new DatagramSocket(); 
        byte[] buffer = new byte[1024];
        String handshake = "this message is used to just know the sender (by IP address)"; // i wont print it on the server therefore.
        String groupName;
        
        buffer = handshake.getBytes();
        InetAddress clientaddress =  InetAddress.getByName("localhost");
        DatagramPacket mypacket = new DatagramPacket(buffer, buffer.length, clientaddress, 4449);
        datagramSocket.send(mypacket); 


         DatagramPacket datagramPacket = new DatagramPacket(buffer, buffer.length);
         ArrayList<String> chatrooms = new ArrayList<>(); // array to hold the sent groups from server.

          int k=0;
        while(k<3)  //receiving the group names from the server
        {
            byte[] newbuffer = new byte[1024];
            DatagramPacket chatroomdatagram = new DatagramPacket(newbuffer, newbuffer.length);
            datagramSocket.receive(chatroomdatagram); 
            groupName = new String(chatroomdatagram.getData(), 0, chatroomdatagram.getLength());
            chatrooms.add(groupName);

            k++;
        }

       
        // section for the clients to choose their respective chatroom.
        int option;
        String clientlines = null; // clinet lines are addresses we will use to hook the clients up on the groups.
        Scanner myscannage = new Scanner(System.in);

     
        for(;;){
           
            System.out.println("which messages do yo want to recieve? choose the chatroom.");
            
            int i = 0, j = 1;

            for (String string : chatrooms)  {  // looping over the array
                System.out.print((j++) + " " + chatrooms.get(i++));
                System.out.println();
            }

            System.out.print("Choice : " );
            option = myscannage.nextInt();

            // linking up the clients to their multicast groups chosen.

            if(option == 1){
        clientlines = "225.1.2.3"; 
        break;
            } 
        else if(option == 2){
        clientlines = "226.2.1.4";
        break;
        }
        else if(option == 3){
        clientlines = "227.3.2.1";
        break;
        }
        
        else 
        System.out.println("opps! didnt catch that well! could you try to enter valid option?.");
        }

       

        try 
        {
            InetAddress group = InetAddress.getByName(clientlines); //address for receiving the broadcast message.

            MulticastSocket mSocket = new MulticastSocket(4000);

            mSocket.joinGroup(group);           //joining the multicast group

            byte[] b = (Integer.toString(option)).getBytes();
            DatagramPacket p = new DatagramPacket(b, b.length, clientaddress, 4449);
            datagramSocket.send(p);

            datagramSocket.close();

          
                byte[] buffer2 = new byte[1024];
                DatagramPacket packet = new DatagramPacket(buffer2, buffer2.length);

                while (true) 
                {
                    mSocket.receive(packet);

                System.out.println(new String(buffer2));
                System.out.println();

                }


        } catch (Exception e) { e.printStackTrace(); }
    }

}
    