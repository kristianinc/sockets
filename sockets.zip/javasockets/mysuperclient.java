

import java.net.*;
import java.util.*;
import java.lang.*;
import java.math.*;

public class mysuperclient {
    
    public static void main(String[] args) throws SocketException, UnknownHostException
    {
        Scanner scannage = new Scanner(System.in);
        System.setProperty("java.net.preferIPv4Stack", "true"); // ipv version four datagram is what we use.
        

        try 
        {     // superclient sends (creates) groups to the server.
            
            InetAddress inetAddress =  InetAddress.getByName("localhost");
            DatagramSocket superclientsocket = new DatagramSocket();

            System.out.println("enter the three chatroom names ");
            
            int chatrooms = 0;
           for(;;){

            String group = scannage.nextLine();
            byte[] buffer = group.getBytes();
            DatagramPacket datagramPacket = new DatagramPacket(buffer, buffer.length, inetAddress, 4449);

            superclientsocket.send(datagramPacket);

            chatrooms++;  
            
            
            System.out.println();
             if(chatrooms == 3)    
                break;      // this loop scans exactly 3 chatrooms from the superclient, then breaks.
             
           }

           System.out.println();
           System.out.println("please enter the time interval in seconds:");
           Scanner timescan = new Scanner(System.in);
           String blinktime = scannage.nextLine();

            byte[] buffer = blinktime.getBytes();
            DatagramPacket datagramPacket = new DatagramPacket(buffer, buffer.length, inetAddress, 4449);
            superclientsocket.send(datagramPacket);
            
           // blink interval scan.

            

            System.out.println(" chatrooms have been created successfully.");
 
        
        } catch (Exception e)
        {
            e.printStackTrace();
            
        }

           
            
    }


}
    

